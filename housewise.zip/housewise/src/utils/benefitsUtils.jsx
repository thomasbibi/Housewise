const benefits = [
    {
        img : '/assets/benefits-3.png',
        title : 'Lower Risk Profile',
        txt : 'House owner contacts housewise representative and authorize him/her to rent out the property(flat/bunglow) on the owner\'s behalf'

    },
    {
        img : '/assets/benefits-1.png',
        title : 'Superior Financing',
        txt : 'House owner hands over keys and relevant property documents to the HouseWise representative'

    },
    {
        img : '/assets/benefits-2.png',
        title : 'Tax Benefits',
        txt : 'HouseWise hunts for tenants the one marking with marquee companies and looking out for a house on rent'

    }
]

export default benefits