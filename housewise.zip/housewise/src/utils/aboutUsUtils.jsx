let icons = [
    {
        img: './assets/icon-properties.png',
        number: 710,
        title: 'properties'
    },
    {
        img: '/assets/icon-sqft.png',
        number: 852000,
        title: 'Square-foot'
    },
    {
        img: '/assets/icon-clients.png',
        number: 3200,
        title: 'Happy Clients'
    },
    {
        img: '/assets/icon-cities.png',
        number: 7,
        title: 'Cities'
    },
    {
        img: '/assets/icon-countries.png',
        number: 21,
        title: 'Countries'
    },
]

export default icons